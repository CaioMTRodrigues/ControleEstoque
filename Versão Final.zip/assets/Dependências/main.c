#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdbool.h>
#include <glib.h>
#include <ctype.h>

#define ARQUIVO_USUARIOS "assets/Database/usuarios.txt"
#define ARQUIVO_ESTOQUE "assets/Database/estoque.txt"
#define MAX_LINHAS 256
#define MAX_SERIES 100

GtkBuilder *builder;
GtkWidget *main_window;
GtkWidget *menu_window;
GtkWidget *entrada_window;
GtkWidget *saida_window;
GtkWidget *sn_window;
GtkWidget *treeview_estoque;
GtkWidget *treeview_serial;
GtkListStore *list_estoque;
GtkListStore *list_serial;

//Funções das janelas
void on_main_window_destroy(GtkWidget *widget, gpointer data){
gtk_main_quit();
}
void on_menu_window_destroy(GtkWidget *widget, gpointer data){
gtk_main_quit();
}
void on_entrada_window_destroy(GtkWidget *widget, gpointer data){
gtk_widget_hide(entrada_window);
gtk_widget_show(menu_window);
}
void on_saida_window_destroy(GtkWidget *widget, gpointer data){
gtk_widget_hide(saida_window);
}
void on_sn_window_destroy(GtkWidget *widget, gpointer data){
gtk_widget_hide(sn_window);
}

//Pop-up's de feedback
void show_dialog_entrou(GtkBuilder *builder) {
    GtkWidget *dialog_entrou = GTK_WIDGET(gtk_builder_get_object(builder, "msg_entrou"));
    gtk_dialog_run(GTK_DIALOG(dialog_entrou));
    gtk_widget_hide(dialog_entrou);
}
void show_dialog_erro(GtkBuilder *builder) {
    GtkWidget *dialog_erro = GTK_WIDGET(gtk_builder_get_object(builder, "msg_erro"));
    gtk_dialog_run(GTK_DIALOG(dialog_erro));
    gtk_widget_hide(dialog_erro);
}
void show_dialog_erroarq(GtkBuilder *builder) {
    GtkWidget *dialog_erroarq = GTK_WIDGET(gtk_builder_get_object(builder, "msg_erroarq"));
    gtk_dialog_run(GTK_DIALOG(dialog_erroarq));
    gtk_widget_hide(dialog_erroarq);
}
void show_dialog_cadastrado(GtkBuilder *builder) {
    GtkWidget *dialog_cadastrado = GTK_WIDGET(gtk_builder_get_object(builder, "msg_cadastrado"));
    gtk_dialog_run(GTK_DIALOG(dialog_cadastrado));
    gtk_widget_hide(dialog_cadastrado);
}
void show_dialog_jaexiste(GtkBuilder *builder) {
    GtkWidget *dialog_jaexiste = GTK_WIDGET(gtk_builder_get_object(builder, "msg_jaexiste"));
    gtk_dialog_run(GTK_DIALOG(dialog_jaexiste));
    gtk_widget_hide(dialog_jaexiste);
}
void show_dialog_erroqtd(GtkBuilder *builder) {
    GtkWidget *dialog_erroqtd = GTK_WIDGET(gtk_builder_get_object(builder, "msg_erroqtd"));
    gtk_dialog_run(GTK_DIALOG(dialog_erroqtd));
    gtk_widget_hide(dialog_erroqtd);
}
void show_dialog_erronome(GtkBuilder *builder) {
    GtkWidget *dialog_erronome = GTK_WIDGET(gtk_builder_get_object(builder, "msg_erronome"));
    gtk_dialog_run(GTK_DIALOG(dialog_erronome));
    gtk_widget_hide(dialog_erronome);
}
void show_dialog_errousuario(GtkBuilder *builder) {
    GtkWidget *dialog_errousuario = GTK_WIDGET(gtk_builder_get_object(builder, "msg_errousuario"));
    gtk_dialog_run(GTK_DIALOG(dialog_errousuario));
    gtk_widget_hide(dialog_errousuario);
}
void show_dialog_errosenha(GtkBuilder *builder) {
    GtkWidget *dialog_errosenha = GTK_WIDGET(gtk_builder_get_object(builder, "msg_errosenha"));
    gtk_dialog_run(GTK_DIALOG(dialog_errosenha));
    gtk_widget_hide(dialog_errosenha);
}

//Função de Verificação do usuário
int verificarUsuario(const char *nome) {
    char nomeArquivo[50], senhaArquivo[50];
    FILE *arquivo = fopen(ARQUIVO_USUARIOS, "r");
    if (!arquivo) {
        return 0;
    }

    while (fscanf(arquivo, "%s %s", nomeArquivo, senhaArquivo) != EOF) {
        if (strcmp(nome, nomeArquivo) == 0) {
            fclose(arquivo);
            return 1;
        }
    }

    fclose(arquivo);
    return 0;
}

//Função de Leitura e interpretação do estoque.txt
void atualizar_estoque(GtkListStore *list_estoque) {
    FILE *arquivo = fopen(ARQUIVO_ESTOQUE, "r");
    if (!arquivo) {
        show_dialog_erroarq(builder);
        return;
    }

    typedef struct {
        char nome[50];
        int quantidade;
    } Item;

    Item itens[100];
    int contadorItens = 0;

    char nome[50], tipo[10], numerosSerie[200];
    int quantidade;

    while (fscanf(arquivo, "\"%49[^\"]\" %d %s %[^\n]\n", nome, &quantidade, tipo, numerosSerie) != EOF) {
        int encontrado = 0;
        for (int i = 0; i < contadorItens; i++) {
            if (strcmp(itens[i].nome, nome) == 0) {
                if (strcmp(tipo, "Entrada") == 0) {
                    itens[i].quantidade += quantidade;
                } else if (strcmp(tipo, "Saida") == 0) {
                    itens[i].quantidade -= quantidade;
                }
                encontrado = 1;
                break;
            }
        }

        if (!encontrado) {
            strcpy(itens[contadorItens].nome, nome);
            itens[contadorItens].quantidade = (strcmp(tipo, "Entrada") == 0) ? quantidade : -quantidade;
            contadorItens++;
        }
    }

    fclose(arquivo);
    gtk_list_store_clear(list_estoque);

    for (int i = 0; i < contadorItens; i++) {
        if (itens[i].quantidade > 0) {
            GtkTreeIter iter;
            gtk_list_store_append(list_estoque, &iter);
            gtk_list_store_set(list_estoque, &iter, 0, itens[i].nome, 1, itens[i].quantidade, -1);
        }
    }
}

//Função de Login
void login(const gchar *user,const gchar *senha)
{
    char nomeArquivo[50], senhaArquivo[50];
    FILE *arquivo = fopen(ARQUIVO_USUARIOS, "r");
    if (!arquivo) {
        show_dialog_erroarq(builder);
        return;
    }

    int autenticado = 0;

    while (fscanf(arquivo, "%49s %49s", nomeArquivo, senhaArquivo) != EOF) {
        if (strcmp(user, nomeArquivo) == 0 && strcmp(senha, senhaArquivo) == 0) {
            autenticado = 1;
            break;
        }
    }
    fclose(arquivo);

    if (autenticado) {
        show_dialog_entrou(builder);
        gtk_widget_hide(main_window);
        gtk_widget_show(menu_window);
        atualizar_estoque(list_estoque);
    } else {
        show_dialog_erro(builder);
    }
}

//Função de Cadastro
void cadastro(const gchar *caduser,const gchar *cadsenha){
    if (verificarUsuario(caduser)) {
        show_dialog_jaexiste(builder);
        return;
    }

    FILE *arquivo = fopen(ARQUIVO_USUARIOS, "a");
    if (!arquivo) {
        show_dialog_erroarq(builder);
    }

    fprintf(arquivo, "%s %s\n", caduser, cadsenha);
    fclose(arquivo);
    show_dialog_cadastrado(builder);
    GtkWidget *stack = GTK_WIDGET(gtk_builder_get_object(builder, "stack"));
    const char *page_login = "page_login";
    gtk_stack_set_visible_child_name(GTK_STACK(stack), page_login);
}

//Função de Pesquisa
G_MODULE_EXPORT void on_button_buscar_clicked(GtkWidget *widget, gpointer data) {
    GtkEntry *entrybusca = GTK_ENTRY(gtk_builder_get_object(builder, "entry_busca"));

    const gchar *busca_texto = gtk_entry_get_text(entrybusca);
    if (strlen(busca_texto) == 0) {
        return; 
    }

    GtkTreeView *treeview_itens = GTK_TREE_VIEW(gtk_builder_get_object(builder, "treeview_itens"));
    GtkTreeModel *model = gtk_tree_view_get_model(treeview_itens);

    GtkTreeIter iter;
    gboolean found = FALSE;

    if (gtk_tree_model_get_iter_first(model, &iter)) {
        do {
            gchar *item_nome;
            gtk_tree_model_get(model, &iter, 0, &item_nome, -1);
            if (strstr(item_nome, busca_texto) != NULL) {
                gtk_tree_view_set_cursor(treeview_itens, gtk_tree_model_get_path(model, &iter), NULL, FALSE);
                found = TRUE;
            }
            g_free(item_nome);
        } while (gtk_tree_model_iter_next(model, &iter));
    }
}

//Página de Login
    //Botão: Entrar (Autenticar Usuário)
G_MODULE_EXPORT void on_button_entrar_clicked(GtkWidget *widget, gpointer data)
{
    GtkEntry *entryloguser = GTK_ENTRY(gtk_builder_get_object(builder, "entry_loguser"));
    const gchar *user = gtk_entry_get_text(entryloguser);
    GtkEntry *entrylogsenha = GTK_ENTRY(gtk_builder_get_object(builder, "entry_logsenha"));
    const gchar *senha = gtk_entry_get_text(entrylogsenha);
    
    if (strlen(user) == 0) {
        show_dialog_errousuario(builder);
        return;
    }
    if (strlen(senha) == 0) {
        show_dialog_errosenha(builder);
        return;
    }
    login(user, senha);
}
    //Botão: Página de cadastro
G_MODULE_EXPORT void on_button_cadastrar_clicked(GtkWidget *widget, gpointer data)
{

    GtkWidget *stack = GTK_WIDGET(gtk_builder_get_object(builder, "stack"));
    const char *page_cadastro = "page_cadastro";
    gtk_stack_set_visible_child_name(GTK_STACK(stack), page_cadastro);
}
    //Botão: Mostrar senha
G_MODULE_EXPORT void on_mostrar_toggled(GtkToggleButton *toggle_button, gpointer data)
{
    
    gboolean is_active = gtk_toggle_button_get_active(toggle_button);
    GtkWidget *entry_logsenha = GTK_WIDGET(gtk_builder_get_object(builder, "entry_logsenha"));
    gtk_entry_set_visibility(GTK_ENTRY(entry_logsenha), is_active);
}

//Página de Cadastro
    //Botão: Cadastrar usuário
G_MODULE_EXPORT void on_button_cadastro_clicked(GtkWidget *widget, gpointer data)
{
    GtkEntry *entrycaduser = GTK_ENTRY(gtk_builder_get_object(builder, "entry_caduser"));
    const gchar *caduser = gtk_entry_get_text(entrycaduser);
    GtkEntry *entrycadsenha = GTK_ENTRY(gtk_builder_get_object(builder, "entry_cadsenha"));
    const gchar *cadsenha = gtk_entry_get_text(entrycadsenha);
    
    if (strlen(caduser) == 0) {
        show_dialog_errousuario(builder);
        return;
    }
    if (strlen(cadsenha) == 0) {
        show_dialog_errosenha(builder);
        return;
    }
    cadastro(caduser, cadsenha);
}
    //Botão: Voltar p/ Login
G_MODULE_EXPORT void on_button_voltarcad_clicked(GtkWidget *widget, gpointer data)
{

    GtkWidget *stack = GTK_WIDGET(gtk_builder_get_object(builder, "stack"));
    const char *page_login = "page_login";
    gtk_stack_set_visible_child_name(GTK_STACK(stack), page_login);
}
    //Botão: Mostrar Senha
G_MODULE_EXPORT void on_mostrarcad_toggled(GtkToggleButton *toggle_button, gpointer data)
{

    gboolean is_active = gtk_toggle_button_get_active(toggle_button);
    GtkWidget *entry_cadsenha = GTK_WIDGET(gtk_builder_get_object(builder, "entry_cadsenha"));
    gtk_entry_set_visibility(GTK_ENTRY(entry_cadsenha), is_active);
}

//Janela de Entrada de itens
    //Botão: Cadastro de Entrada
G_MODULE_EXPORT void on_button_cadentrada_clicked(GtkWidget *widget, gpointer data)
{
    gtk_widget_show(entrada_window);
}
    //Botão: Registrar Entrada de item no estoque.txt
G_MODULE_EXPORT void on_button_cadastroentrada_clicked(GtkWidget *widget, gpointer data)
{   
    GtkEntry *entryentnome = GTK_ENTRY(gtk_builder_get_object(builder, "entry_entnome"));
    const gchar *item_nome = gtk_entry_get_text(entryentnome);
    GtkEntry *entryentqtd = GTK_ENTRY(gtk_builder_get_object(builder, "entry_entqtd"));
    const gchar *item_qtdc = gtk_entry_get_text(entryentqtd);
    GtkEntry *entryentsn = GTK_ENTRY(gtk_builder_get_object(builder, "entry_entsn"));
    const gchar *item_sn = gtk_entry_get_text(entryentsn);  

    if (strlen(item_nome) == 0) {
        show_dialog_erronome(builder);
        return;
    }

    gint item_qtd = 0;
    gboolean qtd_valida = TRUE;
    
    for (int i = 0; item_qtdc[i] != '\0'; i++) {
        if (!isdigit(item_qtdc[i])) {
            qtd_valida = FALSE;
            break;
        }
    }

    if (!qtd_valida || (item_qtd = atoi(item_qtdc)) <= 0) {
        show_dialog_erroqtd(builder);
        return;
    }

    FILE *arquivo = fopen(ARQUIVO_ESTOQUE, "a");
    if (!arquivo) {
        show_dialog_erroarq(builder);
        return;
    }

    fprintf(arquivo, "\"%s\" %d Entrada %s\n", item_nome, item_qtd, item_sn);

    gtk_widget_hide(entrada_window);
    gtk_entry_set_text(GTK_ENTRY(entryentnome), "");
    gtk_entry_set_text(GTK_ENTRY(entryentqtd), "");
    gtk_entry_set_text(GTK_ENTRY(entryentsn), "");

    fclose(arquivo);
    atualizar_estoque(list_estoque);
}
    //Botão: Voltar p/ Menu
G_MODULE_EXPORT void on_button_voltarentrada_clicked(GtkWidget *widget, gpointer data)
{
    gtk_widget_hide(entrada_window);
    gtk_widget_show(menu_window);
}

//Janela de Saída de itens
    //Botão: Cadastro de Saída
G_MODULE_EXPORT void on_button_cadsaida_clicked(GtkWidget *widget, gpointer data)
{
    gtk_widget_show(saida_window);
}
    //Botão: Registrar Saída de item no estoque.txt
G_MODULE_EXPORT void on_button_cadastrosaida_clicked(GtkWidget *widget, gpointer data)
{   
    GtkEntry *entrysadnome = GTK_ENTRY(gtk_builder_get_object(builder, "entry_sadnome"));
    const gchar *item_nome = gtk_entry_get_text(entrysadnome);
    GtkEntry *entrysadqtd = GTK_ENTRY(gtk_builder_get_object(builder, "entry_sadqtd"));
    const gchar *item_qtdc = gtk_entry_get_text(entrysadqtd);
    GtkEntry *entrysadsn = GTK_ENTRY(gtk_builder_get_object(builder, "entry_sadsn"));
    const gchar *item_sn = gtk_entry_get_text(entrysadsn);  

    if (strlen(item_nome) == 0) {
        show_dialog_erronome(builder);
        return;
    }

    gint item_qtd = 0;
    gboolean qtd_valida = TRUE;
    
    for (int i = 0; item_qtdc[i] != '\0'; i++) {
        if (!isdigit(item_qtdc[i])) {
            qtd_valida = FALSE;
            break;
        }
    }

    if (!qtd_valida || (item_qtd = atoi(item_qtdc)) <= 0) {
        show_dialog_erroqtd(builder);
        return;
    }

    FILE *arquivo = fopen(ARQUIVO_ESTOQUE, "a");
        if (!arquivo) {
            show_dialog_erroarq(builder);
            return;
        }
        fprintf(arquivo, "\"%s\" %d Saida %s\n", item_nome, item_qtd, item_sn);
        gtk_widget_hide(saida_window);
        fclose(arquivo);
        gtk_entry_set_text(GTK_ENTRY(entrysadnome), "");
        gtk_entry_set_text(GTK_ENTRY(entrysadqtd), "");
        gtk_entry_set_text(GTK_ENTRY(entrysadsn), "");
        atualizar_estoque(list_estoque);
}
    //Botão: Voltar p/ Menu
G_MODULE_EXPORT void on_button_voltarsaida_clicked(GtkWidget *widget, gpointer data)
{
    gtk_widget_hide(saida_window);
    gtk_widget_show(menu_window);
}

//Janela de Número de Série
int ConferirEstoque(const char *numero, char estoque[MAX_SERIES][10], int total) {
    
    for (int i = 0; i < total; i++) {
        if (strcmp(estoque[i], numero) == 0) {
            return i;
        }
    }
    return -1;
}
    //Sistematização: Mostrar Serial do item selecionado
G_MODULE_EXPORT void on_treeview_itens_row_activated(GtkTreeView *treeview_estoque, GtkTreePath *path, GtkTreeViewColumn *column, gpointer user_data) {
    GtkTreeModel *model;
    GtkTreeIter iter;
    gchar *item_nome;

    model = gtk_tree_view_get_model(treeview_estoque);

    if (gtk_tree_model_get_iter(model, &iter, path)) {
        gtk_tree_model_get(model, &iter, 0, &item_nome, -1);

        FILE *arquivo = fopen(ARQUIVO_ESTOQUE, "r");
        if (!arquivo) {
            show_dialog_erroarq(builder);
            g_free(item_nome);
            return;
        }

        gtk_list_store_clear(list_serial);

        GList *numeros_serie_list = NULL;

        char nome[50], tipo[10], numerosSerie[500];
        int quantidade;

while (fscanf(arquivo, "\"%49[^\"]\" %d %s %[^\n]\n", nome, &quantidade, tipo, numerosSerie) != EOF) {
    if (strcmp(nome, item_nome) == 0) {
        char *serial = strtok(numerosSerie, ",");
        while (serial != NULL) {
            if (strcmp(tipo, "Entrada") == 0) {
                numeros_serie_list = g_list_insert_sorted(numeros_serie_list, g_strdup(serial), (GCompareFunc)g_ascii_strcasecmp);
            } else if (strcmp(tipo, "Saida") == 0) {
                GList *found = g_list_find_custom(numeros_serie_list, serial, (GCompareFunc)g_ascii_strcasecmp);
                if (found) {
                    g_free(found->data);
                    numeros_serie_list = g_list_delete_link(numeros_serie_list, found);
                }
            }
            serial = strtok(NULL, ",");
        }
        continue;
    }
}


        fclose(arquivo);

        for (GList *l = numeros_serie_list; l != NULL; l = l->next) {
            GtkTreeIter iter_serial;
            gtk_list_store_append(list_serial, &iter_serial);
            gtk_list_store_set(list_serial, &iter_serial, 0, (gchar *)l->data, -1);
        }

        g_list_free_full(numeros_serie_list, g_free);
        g_free(item_nome);
        gtk_widget_show(sn_window);
    }
}

   //Botão: Voltar p/ Menu
G_MODULE_EXPORT void on_button_voltarsn_clicked(GtkWidget *widget, gpointer data)
{
    gtk_widget_hide(sn_window);
    gtk_widget_show(menu_window);
}

int main(int argc, char *argv[])
{
    gtk_init(&argc, &argv);
    builder = gtk_builder_new_from_file("assets/Dependências/ui.glade");
    GtkWidget *treeview_itens = GTK_WIDGET(gtk_builder_get_object(builder, "treeview_itens"));
    GtkWidget *treeview_serial = GTK_WIDGET(gtk_builder_get_object(builder, "treeview_serial"));
    g_log_set_handler("GLib-GIO", G_LOG_LEVEL_WARNING, g_log_default_handler, NULL);
    g_log_set_handler("GLib-GObject", G_LOG_LEVEL_WARNING, g_log_default_handler, NULL);

    gtk_builder_add_callback_symbols(
        builder,
        //Callback's: Janelas
        "on_main_window_destroy", G_CALLBACK(on_main_window_destroy),
        "on_menu_window_destroy", G_CALLBACK(on_menu_window_destroy),
        "on_entrada_window_destroy", G_CALLBACK(on_entrada_window_destroy),
        "on_saida_window_destroy", G_CALLBACK(on_saida_window_destroy),
        "on_sn_window_destroy", G_CALLBACK(on_sn_window_destroy),
        //Callback's: Página de Login
        "on_button_entrar_clicked", G_CALLBACK(on_button_entrar_clicked),
        "on_button_cadastrar_clicked", G_CALLBACK(on_button_cadastrar_clicked),
        g_signal_connect(gtk_builder_get_object(builder, "toggle_button"), "toggled", G_CALLBACK(on_mostrar_toggled), builder),
        //Callback's: Página de Cadastro
        "on_button_cadastro_clicked", G_CALLBACK(on_button_cadastro_clicked),
        "on_button_voltarcad_clicked", G_CALLBACK(on_button_voltarcad_clicked),
        g_signal_connect(gtk_builder_get_object(builder, "toggle_button"), "toggled", G_CALLBACK(on_mostrarcad_toggled), builder),
        //Callback's: Cadastro Entrada
        "on_button_cadentrada_clicked", G_CALLBACK(on_button_cadentrada_clicked),
        "on_button_cadastroentrada_clicked", G_CALLBACK(on_button_cadastroentrada_clicked),
        "on_button_voltarentrada_clicked", G_CALLBACK(on_button_voltarentrada_clicked),
        //Callback's: Cadastro Saída
        "on_button_cadsaida_clicked", G_CALLBACK(on_button_cadsaida_clicked),
        "on_button_cadastrosaida_clicked", G_CALLBACK(on_button_cadastrosaida_clicked),
        "on_button_voltarsaida_clicked", G_CALLBACK(on_button_voltarsaida_clicked),
        //Callback's: Número de Série
        "on_button_voltarsn_clicked", G_CALLBACK(on_button_voltarsn_clicked),
        g_signal_connect(treeview_itens, "row-activated", G_CALLBACK(on_treeview_itens_row_activated), builder),
        //Callback's: Pesquisa
        "on_button_buscar_clicked", G_CALLBACK(on_button_buscar_clicked),
        g_signal_connect(gtk_builder_get_object(builder, "button_buscar"), "clicked", G_CALLBACK(on_button_buscar_clicked), builder),
        NULL
    );

    gtk_builder_connect_signals(builder, NULL);

    main_window = GTK_WIDGET(gtk_builder_get_object(builder, "main_window"));
    menu_window = GTK_WIDGET(gtk_builder_get_object(builder, "menu_window"));
    entrada_window = GTK_WIDGET(gtk_builder_get_object(builder, "entrada_window"));
    saida_window = GTK_WIDGET(gtk_builder_get_object(builder,"saida_window"));
    sn_window = GTK_WIDGET(gtk_builder_get_object(builder,"sn_window"));
    list_estoque = GTK_LIST_STORE(gtk_builder_get_object(builder, "list_estoque"));
    list_serial = GTK_LIST_STORE(gtk_builder_get_object(builder, "list_serial"));

    gtk_widget_show_all(main_window);
    gtk_main();
}